'use strict';


// DIFFERENT DATA! Contains movement dates, currency and locale

const account1 = {
  owner: 'Saksham Agrawal',
  movements: [200, 455.23, -306.5, 25000, -642.21, -133.9, 79.97, 1300],
  interestRate: 1.2, // %
  pin: 1111,

  movementsDates: [
    '2019-11-18T21:31:17.178Z',
    '2019-12-23T07:42:02.383Z',
    '2020-01-28T09:15:04.904Z',
    '2020-04-01T10:17:24.185Z',
    '2020-05-08T14:11:59.604Z',
    '2020-05-27T17:01:17.194Z',
    '2020-07-11T23:36:17.929Z',
    '2020-07-12T10:51:36.790Z',
  ],
  currency: 'INR',
  locale: 'en-IN', // de-DE
};

const account2 = {
  owner: 'XYZ ABC',
  movements: [5000, 3400, -150, -790, -3210, -1000, 8500, -30],
  interestRate: 1.5,
  pin: 2222,

  movementsDates: [
    '2019-11-01T13:15:33.035Z',
    '2019-11-30T09:48:16.867Z',
    '2019-12-25T06:04:23.907Z',
    '2020-01-25T14:18:46.235Z',
    '2020-02-05T16:33:06.386Z',
    '2020-04-10T14:43:26.374Z',
    '2020-06-25T18:49:59.371Z',
    '2020-07-26T12:01:20.894Z',
  ],
  currency: 'USD',
  locale: 'en-US',
};

const accounts = [account1, account2];




/////////////////////////////////////////////////
/////////////////////////////////////////////////
// BANKIST APP

// Data
// const account1 = {
//   owner: 'Pradeep Kumar Agrawal',
//   movements: [200, 450, -400, 3000, -650, -130, 70, 1300],
//   interestRate: 1.2, // %
//   pin: 1111,
// };

// const account2 = {
//   owner: 'Priyanshi Agrawal',
//   movements: [5000, 3400, -150, -790, -3210, -1000, 8500, -30],
//   interestRate: 1.5,
//   pin: 2222,
// };

// const account3 = {
//   owner: 'Saksham Agrawal',
//   movements: [200, -200, 340, -300, -20, 50, 400, -460],
//   interestRate: 0.7,
//   pin: 3333,
// };

// const account4 = {
//   owner: 'Bharti Agrawal',
//   movements: [430, 1000, 700, 50, 90],
//   interestRate: 1,
//   pin: 4444,
// };

// const accounts = [account1, account2, account3, account4];

// Elements
const labelWelcome = document.querySelector('.welcome');
const labelDate = document.querySelector('.date');
const labelBalance = document.querySelector('.balance__value');
const labelSumIn = document.querySelector('.summary__value--in');
const labelSumOut = document.querySelector('.summary__value--out');
const labelSumInterest = document.querySelector('.summary__value--interest');
const labelTimer = document.querySelector('.timer');

const containerApp = document.querySelector('.app');
const containerMovements = document.querySelector('.movements');

const btnLogin = document.querySelector('.login__btn');
const btnTransfer = document.querySelector('.form__btn--transfer');
const btnLoan = document.querySelector('.form__btn--loan');
const btnClose = document.querySelector('.form__btn--close');
const btnSort = document.querySelector('.btn--sort');

const inputLoginUsername = document.querySelector('.login__input--user');
const inputLoginPin = document.querySelector('.login__input--pin');
const inputTransferTo = document.querySelector('.form__input--to');
const inputTransferAmount = document.querySelector('.form__input--amount');
const inputLoanAmount = document.querySelector('.form__input--loan-amount');
const inputCloseUsername = document.querySelector('.form__input--user');
const inputClosePin = document.querySelector('.form__input--pin');



const dateAndDays = function (date , locale){
  const calcDaysPassed = (date1, date2) => Math.round(Math.abs(date2-date1)/(1000 * 60 * 60 * 24));

  const daysPassed = calcDaysPassed(new Date(), date);

  if (daysPassed === 0) return `Today`;
  if (daysPassed === 1) return `Yesterday`;
  if (daysPassed <= 7) return `${daysPassed} days ago`;

  return new Intl.DateTimeFormat(locale).format(date);

}

const formattedCurrency = function(value , locale , currency){
  return new Intl.NumberFormat(locale , {
    style : 'currency', currency : currency 
  }).format(value);
}


//function to create movements i.e deposit and withdraw of money, rows for transfer of money
// containerMovement is the variable we made above to select .movements
const displayMovements = function(acc , sort = false){
  // now to remove the previous html, as our code below only adds html , but what will happen to prev html ? 
  // it will stay there, and our element will be shown before the old html(because of afterbegin), so to remove old html
  containerMovements.innerHTML = '';

  // For sorting 
  // for ascending .sort((a,b) => a-b)
  // for descending .sort((a,b) => b-a)
  // whenever sort will be true
  const movs = sort ? acc.movements.slice().sort((a,b) => a-b) : acc.movements;

  movs.forEach(function(mov, i){
    // changing type, either deposit or withdraw, as specified in our html classnames
    const type = mov > 0 ? 'deposit' : 'withdrawal';

    // date and time of movements
    const date = new Date(acc.movementsDates[i]);
    const displayDate = dateAndDays(date , acc.locale);

    // currency 
    const displayCurrency = formattedCurrency(mov , acc.locale , acc.currency);

    // changing the html of our webpage, and using template literals to ease off our work
    const html = `
    <div class="movements__row">
      <div class="movements__type movements__type--${type}">${i+1} ${type}</div>
      <div class="movements__date">${displayDate}</div>
      <div class="movements__value">${displayCurrency}</div>
    </div>`// toFixed will fix value to 2 decimal places

    //method that inserts our manipulated html, afterbegin is just a predefined method of .insertAdjacentHTML
    containerMovements.insertAdjacentHTML('afterbegin' , html)
  })
}


// calculating and printing balance of an account
const calcPrintBalance = function(acc){
  //In reduce in each iteration acc+mov is returned for next loop, i.e acc+mov will replace acc in next iteration
  //We start the acc value with 0, that is why we have written 0
  // Creating a new property in our account called balance, to keep track of balance
  acc.balance = acc.movements.reduce((acc , mov) => acc + mov , 0);
  // LabelBalance is querySelector element we made above
  labelBalance.textContent = formattedCurrency(acc.balance , acc.locale , acc.currency);

}


// To show balance in account
const calcDisplaySummary = function(acc){
  const incomes = acc.movements.filter(mov => mov > 0).reduce((acc , mov) => acc+mov , 0);

  const out = acc.movements.filter(mov => mov < 0).reduce((acc , mov) => acc+mov , 0);

  const interest =  acc.movements.filter(mov => mov > 0).map(deposit => (deposit*acc.interestRate)/100)
  .filter(deposit => deposit > 1)
  .reduce((acc , int) => acc+int , 0);

  // Made a variable using querySelector
  labelSumIn.textContent = formattedCurrency(incomes , acc.locale , acc.currency);

  labelSumOut.textContent = formattedCurrency(out , acc.locale , acc.currency);

  labelSumInterest.textContent = formattedCurrency(interest , acc.locale , acc.currency);

}



// now to create username for each user
// if you can't remember see what does map function do (150)
const createUsername = function(accs){

  /* this function won't return anything, we simply loop over accounts array and each iteration we manipulate 
  the current account object and added username to it based on account owner */
  accs.forEach(function(acc){
    // as we owner in each account (if we had name instead of owner we would have wrote acc.name)
    acc.username = acc.owner.toLowerCase().split(' ').map(name => name[0]).join('');

  })
}
createUsername(accounts);


const startLogOutTimer = function(){

  const tick = function(){
    const min = String(Math.trunc(time/60)).padStart(2, 0);
    const sec = String(time % 60).padStart(2, 0);

    // In each call print remaining time in UI
    labelTimer.textContent =`${min}:${sec}`;


    if (time === 0){
      clearInterval(timer)
      labelWelcome.textContent = `Log in to get started`
      containerApp.style.opacity = 0;
    }

    time--;
    
  }
  
  // set timer to 5 minutes
  let time = 300;

  tick();
  // call fn every second
  const timer = setInterval(tick , 1000)
  return timer;
}

// We will need this variable in many functions that is why we declared it globally
let currentAccount , timer;


const updateUI = function(acc){
  
    // display movements , balance , summary
    displayMovements(currentAccount);
    calcPrintBalance(currentAccount);
    calcDisplaySummary(currentAccount);
}


// Creating login
// Made variable for button, username, password above
btnLogin.addEventListener('click' , function(e){
  // prevent form from submitting (reloading the page)
  e.preventDefault();
  // Finding account from accounts object
  currentAccount = accounts.find(acc => acc.username === inputLoginUsername.value) //.value reads the value of a field(text box)
  // password         // ? is optional chaining, we will check for pin iff currentAcoount exists
  if (currentAccount?.pin === Number(inputLoginPin.value)){

    
    // We have to display UI and welcome message
    labelWelcome.textContent = `Welcome, ${currentAccount.owner}`
    containerApp.style.opacity = 100;

    
    // DATE 
    const date = new Date();

    // International API / Date
    const options = {
      hour : 'numeric', minute : 'numeric' , day : 'numeric' , month : 'long' , year : 'numeric' , 
      weekday : 'long'
    }

    labelDate.textContent = new Intl.DateTimeFormat(currentAccount.locale , options).format(date);

   /* const day = `${date.getDate()}`.padStart(2, 0);
    const mon = `${date.getMonth() + 1}`.padStart(2, 0);  // indexing of months start from 0
    const year = date.getFullYear();
    const hour = date.getHours();
    const min = date.getMinutes();
    labelDate.textContent = `${day}/${mon}/${year}, ${hour}:${min}`*/


    // clearing input values
    inputLoginUsername.value = inputLoginPin.value = '';
    inputLoginPin.blur();

    // So that timer resets every time a new user logs in, else there will be multiple timers running and it will mess up UI
    if (timer) clearInterval(timer)
    timer = startLogOutTimer();

    updateUI(currentAccount);
  }
})


// Transfering from 1 acc to another
btnTransfer.addEventListener('click' , function(e){
  e.preventDefault();

  const amount = Number(inputTransferAmount.value)
  const recievingAcc = accounts.find(acc => acc.owner === inputTransferTo.value);

  inputTransferAmount.value = inputTransferTo.value = '';


  if (amount > 0 && currentAccount.balance >= amount && recievingAcc
    && recievingAcc?.username !== currentAccount.username){
      // Doing the Transfer
      currentAccount.movements.push(-amount);
      recievingAcc.movements.push(amount);

      currentAccount.movementsDates.push(new Date().toISOString());
      recievingAcc.movementsDates.push(new Date().toISOString());

      updateUI(currentAccount);

      clearInterval(timer)
      timer = startLogOutTimer();
    }
})


// Loan
btnLoan.addEventListener('click', function(e){
  e.preventDefault();

  // floor will round up the value and will do automatic coersion
  const amount = Math.floor(inputLoanAmount.value);
  // some is used to check for condition
  if (amount > 0 && currentAccount.movements.some(move => move >= amount * 0.1)){

   setTimeout (function() {currentAccount.movements.push(amount);
    currentAccount.movementsDates.push(new Date().toISOString());

    updateUI(currentAccount);}, 10000);
    clearInterval(timer)
    timer = startLogOutTimer();

  } 
  inputLoanAmount.value = '';
})



// Closing Account
btnClose.addEventListener('click' , function(e){
  e.preventDefault();

  if(inputCloseUsername.value === currentAccount.username 
    && Number(inputClosePin.value) === currentAccount.pin){
      const index = accounts.findIndex(acc => acc.username === currentAccount.username)

      // delete 
      accounts.splice(index);

      // hide ui 
      containerApp.style.opacity = 0;
      labelWelcome.textContent = "Log in to get started";
    }
    inputCloseUsername.value = inputClosePin.value = '';
})


// changing sort to true, so that our movements will be sorted (in displayMovements)
let sorted = false;
btnSort.addEventListener('click' , function(e){
  e.preventDefault();
  displayMovements(currentAccount , !sorted)
  // so that we can reverse back to normal form from sorted form
  sorted = !sorted;
})

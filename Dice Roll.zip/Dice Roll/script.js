'use strict';

// Players
const player0El = document.querySelector('.player--0');
const player1El = document.querySelector('.player--1');
// # as score--0 is an Id
const score0El = document.querySelector('#score--0');
// we can also use getElementById, we don't have to put # for that
const score1El = document.getElementById('score--1');
const diceEl = document.querySelector('.dice');
const btnNew = document.querySelector('.btn--new');
const btnRoll = document.querySelector('.btn--roll');
const btnHold = document.querySelector('.btn--hold');

// current score for player 0
const current0El = document.getElementById('current--0');

// current score for player 1
const current1El = document.getElementById('current--1');

// declaring variables outside so they won't be instance to reset function
let scores, currentScore, activePlayer, playing;

// function to reset the game
const reset = function () {

  // Starting Conditions
  // scores for player 0 and player 1
  scores = [0, 0];
  // variable for current score
  currentScore = 0;
  // variable for active player
  activePlayer = 0;
  // playing state
  playing = true; // put all our button code inside playing so that if player has won then button will turn off
  score0El.textContent = 0;
  score1El.textContent = 0;
  diceEl.classList.add('hidden');

  current0El.textContent = 0;
  current1El.textContent = 0;

  player0El.classList.remove('player--winner');
  player1El.classList.remove('player--winner');
  player0El.classList.add('player--active');
  player1El.classList.remove('player--active');
};

reset();

// function to switch players
const switchPlayer = function () {
  document.getElementById(`current--${activePlayer}`).textContent = 0;
  currentScore = 0;

  activePlayer = activePlayer === 0 ? 1 : 0;
  player0El.classList.toggle('player--active');
  player1El.classList.toggle('player--active');
};

// Button Roll functionality
btnRoll.addEventListener('click', function () {
  if (playing) {
    // generate random dice roll
    const dice = Math.trunc(Math.random() * 6) + 1;

    // display Dice
    diceEl.classList.remove('hidden');
    diceEl.src = `dice-${dice}.png`;

    // check for (if rolled 1 : switch the player)
    if (dice !== 1) {
      currentScore += dice;
      document.getElementById(`current--${activePlayer}`).textContent =
        currentScore;
    } else {
      // switch to next player
      switchPlayer();
    }
  }
});

btnHold.addEventListener('click', function () {
  if (playing) {
    // Add current score to active players score
    scores[activePlayer] += currentScore;
    document.getElementById(`score--${activePlayer}`).textContent =
      scores[activePlayer];
    // check if players score is >=100
    if (scores[activePlayer] >= 100) {
      // finish the score
      playing = false;
      diceEl.classList.add('hidden');
      document
        .querySelector(`.player--${activePlayer}`)
        .classList.add('player--winner');
      document
        .querySelector(`.player--${activePlayer}`)
        .classList.remove('player--active');
    } else {
      // switch to the next player
      switchPlayer();
    }
  }
});

btnNew.addEventListener('click', reset);

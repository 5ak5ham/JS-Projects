'use strict';

// Generating Random Number
let secretNumber = Math.trunc(Math.random() * 20) + 1;


// Score Tracker
let scoreTracker = 10;
let highScore = 0;


//creating a function to remove tedious code of writing document.querySelector('.message').textContent
const displayMsg = function (msg){
    document.querySelector('.message').textContent = msg;
}


/*
 querySelector = To select an element from HTML, . for classes and # for id's
 addEventListener = Listens to the event that happens in our application
 function is our event hander, i.e what will happen on click as we gave event as 'click'
*/
document.querySelector('.check').addEventListener('click' , function(){


    // We had to wrap it in Number because whenever we get something from UI it is usually a String, but as we have to compare it to number we will change the type to number
    const guess = Number(document.querySelector('.guess').value); 
    console.log(guess);


    // If we do not put any value then defualt number generated will be 0, i.e a falsy value, so we put !guess to change it to true and so will out if statement will be executed
    // There is no input
    if (!guess){
        // textContent brings the text of our element (i.e message here)
        displayMsg("🚫 No Value Entered");
    }


    // When player wins
    else if (guess === secretNumber){
        displayMsg("🎉 Correct Guess!");

        
        // Hiding the secretNumber so it is only shown when user wins
        document.querySelector('.number').textContent = secretNumber;


        /*
         Manipulating CSS on winning
         As body is an element we won't use . or #
         .style helps us to manipulate CSS
         We have to write properties in camelCase
        */
        document.querySelector('body').style.backgroundColor = "#60b347";
        document.querySelector('.number').style.width = "30rem";


        // highscore logic
        if (scoreTracker>highScore){
            highScore = scoreTracker;
            document.querySelector('.highscore').textContent = highScore;
        }
        

    }


    // When guess is lower than secret number
    else if (guess !== secretNumber){
        if (scoreTracker > 1){
            if (secretNumber > guess){
                if ((secretNumber - guess) < 3) displayMsg("Go Higher");
                else displayMsg("📉 Too Low !");
                scoreTracker--;
                document.querySelector('.score').textContent = scoreTracker;
            }
            else if (guess > secretNumber){
                if ((guess - secretNumber) < 3) displayMsg("Go Lower");
                else displayMsg("📈 Too High !");
                scoreTracker--;
                document.querySelector('.score').textContent = scoreTracker;
            }
        }
        else {
            displayMsg("☹️ YOU LOOOOOSE");
            document.querySelector('.score').textContent = 0;
        }
    }

});


// For reset button to reset the game
document.querySelector('.again').addEventListener('click' , function(){

    scoreTracker = 10;
    secretNumber = Math.trunc(Math.random() * 20) + 1;

    document.querySelector('body').style.backgroundColor = "#222";
    document.querySelector('.number').textContent = '?';
    document.querySelector('.number').style.width = "15rem";
    displayMsg("Start guessing...");
    document.querySelector('.score').textContent = scoreTracker;
    document.querySelector('.guess').value = '';

});